# startpage-sanctuary
Startup Page for browsers. 
![Sanctuary](pictures/image2.png)


### Installation
Clone the repo or download the zip and set the file path for index.html as the homepage url. Should look similar to the below:

`file:///home/papa/Documents/startpage-sanctuary-main/index.html`
